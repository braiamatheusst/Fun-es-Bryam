# Funções-Bryam
